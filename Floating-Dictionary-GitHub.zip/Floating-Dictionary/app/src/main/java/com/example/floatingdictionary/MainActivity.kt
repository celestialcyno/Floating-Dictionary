package com.example.floatingdictionary

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView

class MainActivity : Activity() {

    private var startAfterPermission = false
    private lateinit var statusText: TextView
    private lateinit var actionButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.permissionStatus)
        actionButton = findViewById(R.id.actionButton)
        actionButton.setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                startFloatingService()
            } else {
                startAfterPermission = true
                val permissionIntent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(permissionIntent)
            }
        }
        updatePermissionStatus()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
        if (startAfterPermission && Settings.canDrawOverlays(this)) {
            startAfterPermission = false
            startFloatingService()
        }
    }

    private fun updatePermissionStatus() {
        val hasPermission = Settings.canDrawOverlays(this)
        statusText.text = if (hasPermission) {
            "Overlay permission is enabled. Start the floating bubble whenever you need it."
        } else {
            "Allow display over other apps so the dictionary bubble can appear above other apps."
        }
        actionButton.text = if (hasPermission) "Start floating bubble" else "Grant permission and start"
    }

    private fun startFloatingService() {
        val serviceIntent = Intent(this, FloatingService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
        statusText.text = "Floating Dictionary is running. Tap its bubble to search."
    }
}
