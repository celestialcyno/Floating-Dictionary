package com.example.floatingdictionary

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object SavedWordsStore {
    data class SavedWord(
        val word: String,
        val definition: String,
        val synonyms: List<String>,
        val savedAt: Long
    )

    private const val PREFS_NAME = "floating_dictionary_saved_words"
    private const val KEY_WORDS = "words_json"
    private val lock = Any()

    fun all(context: Context): List<SavedWord> = synchronized(lock) {
        readUnsafe(context).sortedByDescending { it.savedAt }
    }

    fun contains(context: Context, word: String): Boolean = synchronized(lock) {
        readUnsafe(context).any { it.word.equals(word.trim(), ignoreCase = true) }
    }

    fun save(context: Context, word: String, definition: String, synonyms: List<String>) = synchronized(lock) {
        val cleanWord = word.trim()
        if (cleanWord.isEmpty()) return@synchronized
        val words = readUnsafe(context).toMutableList()
        words.removeAll { it.word.equals(cleanWord, ignoreCase = true) }
        words.add(
            0,
            SavedWord(
                word = cleanWord,
                definition = definition.trim(),
                synonyms = synonyms.map { it.trim() }.filter { it.isNotEmpty() }.distinct(),
                savedAt = System.currentTimeMillis()
            )
        )
        writeUnsafe(context, words)
    }

    fun remove(context: Context, word: String) = synchronized(lock) {
        val words = readUnsafe(context).filterNot { it.word.equals(word.trim(), ignoreCase = true) }
        writeUnsafe(context, words)
    }

    fun clear(context: Context) = synchronized(lock) {
        writeUnsafe(context, emptyList())
    }

    private fun readUnsafe(context: Context): List<SavedWord> {
        val preferences = context.applicationContext
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = preferences.getString(KEY_WORDS, "[]") ?: "[]"
        return try {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    val word = item.optString("word", "").trim()
                    if (word.isEmpty()) continue
                    val synonymsArray = item.optJSONArray("synonyms") ?: JSONArray()
                    val synonyms = buildList {
                        for (synonymIndex in 0 until synonymsArray.length()) {
                            val synonym = synonymsArray.optString(synonymIndex).trim()
                            if (synonym.isNotEmpty()) add(synonym)
                        }
                    }
                    add(
                        SavedWord(
                            word = word,
                            definition = item.optString("definition", ""),
                            synonyms = synonyms,
                            savedAt = item.optLong("savedAt", 0L)
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun writeUnsafe(context: Context, words: List<SavedWord>) {
        val array = JSONArray()
        words.forEach { savedWord ->
            val synonyms = JSONArray()
            savedWord.synonyms.forEach { synonyms.put(it) }
            array.put(
                JSONObject()
                    .put("word", savedWord.word)
                    .put("definition", savedWord.definition)
                    .put("synonyms", synonyms)
                    .put("savedAt", savedWord.savedAt)
            )
        }
        context.applicationContext
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_WORDS, array.toString())
            .apply()
    }
}
