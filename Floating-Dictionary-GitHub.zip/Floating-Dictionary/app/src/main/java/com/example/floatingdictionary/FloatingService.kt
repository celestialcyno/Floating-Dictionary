package com.example.floatingdictionary

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.Html
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs

class FloatingService : Service() {

    companion object {
        private const val CHANNEL_ID = "floating_dictionary_service"
        private const val NOTIFICATION_ID = 1001
    }

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var panelOpen = false
    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())

        if (Settings.canDrawOverlays(this) && overlayView == null) {
            showOverlay()
        } else if (!Settings.canDrawOverlays(this)) {
            stopSelf()
        }
        return START_STICKY
    }

    private fun showOverlay() {
        val root = View.inflate(this, R.layout.floating_layout, null)
        val bubble = root.findViewById<TextView>(R.id.floatingBubble)
        val panel = root.findViewById<View>(R.id.searchPanel)
        val wordInput = root.findViewById<EditText>(R.id.wordInput)
        val searchButton = root.findViewById<Button>(R.id.searchButton)
        val closeButton = root.findViewById<Button>(R.id.closeButton)
        val stopBubbleButton = root.findViewById<Button>(R.id.stopBubbleButton)
        val definitionText = root.findViewById<TextView>(R.id.definitionText)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val initialFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            initialFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(120)
        }

        overlayView = root
        overlayParams = params
        try {
            windowManager.addView(root, params)
        } catch (exception: Exception) {
            overlayView = null
            overlayParams = null
            stopSelf()
            return
        }

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        bubble.setOnTouchListener(object : View.OnTouchListener {
            private var downRawX = 0f
            private var downRawY = 0f
            private var startX = 0
            private var startY = 0
            private var moved = false

            override fun onTouch(view: View, event: MotionEvent): Boolean {
                val currentParams = overlayParams ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downRawX = event.rawX
                        downRawY = event.rawY
                        startX = currentParams.x
                        startY = currentParams.y
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - downRawX
                        val dy = event.rawY - downRawY
                        if (abs(dx) > touchSlop || abs(dy) > touchSlop) moved = true
                        if (moved) {
                            currentParams.x = startX + dx.toInt()
                            currentParams.y = startY + dy.toInt()
                            try {
                                windowManager.updateViewLayout(root, currentParams)
                            } catch (_: Exception) {
                                // The overlay may have been removed while the user was dragging.
                            }
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) togglePanel(panel, wordInput)
                        return true
                    }
                    MotionEvent.ACTION_CANCEL -> return true
                }
                return true
            }
        })

        searchButton.setOnClickListener {
            val word = wordInput.text.toString().trim()
            if (word.isEmpty()) {
                definitionText.text = "Type a word to look it up."
            } else {
                lookupWord(word, definitionText)
            }
        }
        closeButton.setOnClickListener { closePanel(panel, wordInput) }
        stopBubbleButton.setOnClickListener {
            closePanel(panel, wordInput)
            stopSelf()
        }
    }

    private fun togglePanel(panel: View, wordInput: EditText) {
        if (panelOpen) {
            closePanel(panel, wordInput)
            return
        }
        val root = overlayView ?: return
        val params = overlayParams ?: return
        panel.visibility = View.VISIBLE
        panelOpen = true
        params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        try {
            windowManager.updateViewLayout(root, params)
        } catch (_: Exception) {
            return
        }
        wordInput.requestFocus()
        wordInput.post {
            val inputMethodManager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            inputMethodManager.showSoftInput(wordInput, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun closePanel(panel: View, wordInput: EditText) {
        val root = overlayView ?: return
        val params = overlayParams ?: return
        val inputMethodManager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(wordInput.windowToken, 0)
        panel.visibility = View.GONE
        wordInput.clearFocus()
        panelOpen = false
        params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        try {
            windowManager.updateViewLayout(root, params)
        } catch (_: Exception) {
            // Service may be shutting down.
        }
    }

    private fun lookupWord(word: String, output: TextView) {
        output.text = "Searching…"
        executor.execute {
            val result = try {
                val encodedWord = URLEncoder.encode(word, "UTF-8").replace("+", "%20")
                val connection = URL("https://en.wiktionary.org/api/rest_v1/page/definition/$encodedWord")
                    .openConnection() as HttpURLConnection
                try {
                    connection.requestMethod = "GET"
                    connection.connectTimeout = 15_000
                    connection.readTimeout = 20_000
                    connection.setRequestProperty("Accept", "application/json")
                    connection.setRequestProperty(
                        "User-Agent",
                        "FloatingDictionary/1.0 (Android; English Wiktionary lookup)"
                    )
                    val status = connection.responseCode
                    val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                    val response = if (stream != null) {
                        BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
                    } else {
                        ""
                    }
                    if (status in 200..299) {
                        formatDefinition(response, word)
                    } else if (status == HttpURLConnection.HTTP_NOT_FOUND) {
                        "No English Wiktionary entry was found for ‘$word’."
                    } else {
                        "Wiktionary returned HTTP $status. Please try again."
                    }
                } finally {
                    connection.disconnect()
                }
            } catch (exception: Exception) {
                val reason = if (exception is java.net.SocketTimeoutException) {
                    "The request timed out. Check your connection and try again."
                } else {
                    exception.localizedMessage ?: "check your internet connection"
                }
                "Could not reach English Wiktionary: $reason"
            }
            mainHandler.post {
                if (overlayView != null && output.isAttachedToWindow) output.text = result
            }
        }
    }

    private fun formatDefinition(response: String, requestedWord: String): String {
        val responseObject = JSONObject(response)
        val entries = responseObject.optJSONArray("en") ?: JSONArray()
        val output = StringBuilder()
        val synonyms = LinkedHashSet<String>()
        var definitionsAdded = 0

        for (entryIndex in 0 until entries.length()) {
            val entry = entries.optJSONObject(entryIndex) ?: continue
            if (output.isEmpty()) {
                output.append("English Wiktionary: ").append(requestedWord).append("\n\n")
            }
            val partOfSpeech = entry.optString("partOfSpeech", "")
            if (partOfSpeech.isNotBlank()) output.append(partOfSpeech).append('\n')
            val definitions = entry.optJSONArray("definitions") ?: JSONArray()
            for (definitionIndex in 0 until definitions.length()) {
                val definition = definitions.optJSONObject(definitionIndex) ?: continue
                val html = definition.optString("definition", "")
                val text = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY)
                    .toString()
                    .replace(Regex("\\s+"), " ")
                    .trim()
                if (text.isNotBlank() && definitionsAdded < 6) {
                    output.append("• ").append(text).append('\n')
                    definitionsAdded++
                }
                addJsonStrings(synonyms, definition.optJSONArray("synonyms"))
            }
            addJsonStrings(synonyms, entry.optJSONArray("synonyms"))
            output.append('\n')
        }

        if (definitionsAdded == 0) {
            return "Wiktionary did not return an English definition for ‘$requestedWord’."
        }
        if (synonyms.isNotEmpty()) {
            output.append("Synonyms: ").append(synonyms.take(12).joinToString(", "))
        } else {
            output.append("Synonyms: see the Wiktionary entry below")
        }
        val pageTitle = URLEncoder.encode(requestedWord.replace(' ', '_'), "UTF-8")
            .replace("+", "%20")
        output.append("\n\nSource: English Wiktionary (CC BY-SA)\n")
            .append("https://en.wiktionary.org/wiki/")
            .append(pageTitle)
        return output.toString().trim()
    }

    private fun addJsonStrings(destination: MutableSet<String>, values: JSONArray?) {
        if (values == null) return
        for (index in 0 until values.length()) {
            val value = values.optString(index).trim()
            if (value.isNotEmpty()) destination.add(value)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Floating Dictionary",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the floating dictionary bubble available"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val activityIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            activityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Floating Dictionary is running")
            .setContentText("Tap the floating bubble to search for a word")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        val view = overlayView
        if (view != null) {
            try {
                windowManager.removeViewImmediate(view)
            } catch (_: Exception) {
                // It may already have been removed by the system.
            }
        }
        overlayView = null
        overlayParams = null
        executor.shutdownNow()
        stopForeground(true)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
