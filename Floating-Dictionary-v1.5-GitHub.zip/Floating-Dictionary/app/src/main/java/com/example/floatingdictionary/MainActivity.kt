package com.example.floatingdictionary

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private var startAfterPermission = false
    private lateinit var statusText: TextView
    private lateinit var actionButton: Button
    private lateinit var savedWordsContainer: LinearLayout
    private lateinit var savedWordsEmpty: TextView
    private lateinit var savedWordsCount: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(AppPreferences.resolveTheme(this))
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.permissionStatus)
        actionButton = findViewById(R.id.actionButton)
        savedWordsContainer = findViewById(R.id.savedWordsContainer)
        savedWordsEmpty = findViewById(R.id.savedWordsEmpty)
        savedWordsCount = findViewById(R.id.savedWordsCount)

        actionButton.setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                startFloatingService()
            } else {
                startAfterPermission = true
                val permissionIntent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(permissionIntent)
            }
        }
        findViewById<Button>(R.id.settingsButton).setOnClickListener { showSettings() }
        updatePermissionStatus()
        refreshSavedWords()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
        refreshSavedWords()
        if (startAfterPermission && Settings.canDrawOverlays(this)) {
            startAfterPermission = false
            startFloatingService()
        }
    }

    private fun updatePermissionStatus() {
        val hasPermission = Settings.canDrawOverlays(this)
        statusText.text = if (hasPermission) {
            "Overlay access is ready. Start the bubble when you want to look up a word."
        } else {
            "Allow display over other apps so the dictionary can appear while you read."
        }
        actionButton.text = if (hasPermission) "Start floating bubble" else "Allow overlay & continue"
    }

    private fun startFloatingService() {
        val serviceIntent = Intent(this, FloatingService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
        statusText.text = "Floating Dictionary is active. Tap its bubble to search."
    }

    private fun refreshSavedWords() {
        if (!::savedWordsContainer.isInitialized) return
        val savedWords = SavedWordsStore.all(this)
        savedWordsContainer.removeAllViews()
        savedWordsCount.text = savedWords.size.toString()
        savedWordsEmpty.visibility = if (savedWords.isEmpty()) View.VISIBLE else View.GONE

        savedWords.forEach { savedWord ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(10), dp(8), dp(10))
                background = getDrawable(R.drawable.card_background)
                isFocusable = true
                isClickable = true
            }
            val textColumn = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setOnClickListener { showSavedWord(savedWord) }
            }
            val wordView = TextView(this).apply {
                text = savedWord.word
                textSize = 17f
                setTextColor(colorFromTheme(android.R.attr.textColorPrimary))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            }
            val snippet = savedWord.definition
                .replace(Regex("\\s+"), " ")
                .take(112)
                .let { if (savedWord.definition.length > 112) "$it…" else it }
            val definitionView = TextView(this).apply {
                text = snippet.ifBlank { "Tap to view saved lookup" }
                textSize = 13f
                setTextColor(colorFromTheme(android.R.attr.textColorSecondary))
                maxLines = 2
                setPadding(0, dp(3), 0, 0)
            }
            textColumn.addView(wordView)
            textColumn.addView(definitionView)
            textColumn.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

            val removeButton = Button(this).apply {
                text = "Remove"
                isAllCaps = false
                minWidth = dp(72)
                setOnClickListener {
                    SavedWordsStore.remove(this@MainActivity, savedWord.word)
                    refreshSavedWords()
                }
            }
            card.addView(textColumn)
            card.addView(removeButton)
            card.setOnClickListener { showSavedWord(savedWord) }
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
            savedWordsContainer.addView(card, params)
        }
    }

    private fun showSavedWord(savedWord: SavedWordsStore.SavedWord) {
        val message = buildString {
            append(savedWord.definition.ifBlank { "No definition was stored." })
            if (savedWord.synonyms.isNotEmpty()) {
                append("\n\nSynonyms\n")
                append(savedWord.synonyms.joinToString(", "))
            }
        }
        AlertDialog.Builder(this)
            .setTitle(savedWord.word)
            .setMessage(message)
            .setPositiveButton("Remove from saved") { _, _ ->
                SavedWordsStore.remove(this, savedWord.word)
                refreshSavedWords()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showSettings() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), dp(8))
        }
        val scroll = ScrollView(this).apply { addView(content) }

        content.addView(sectionLabel("Appearance"))
        val themeValues = listOf(
            AppPreferences.THEME_LIGHT to "Light",
            AppPreferences.THEME_DARK to "Dark",
            AppPreferences.THEME_SYSTEM to "Follow device"
        )
        val themeGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        var selectedThemeId = View.NO_ID
        themeValues.forEach { (value, label) ->
            val radio = RadioButton(this).apply {
                id = View.generateViewId()
                text = label
                setTextColor(colorFromTheme(android.R.attr.textColorPrimary))
                if (value == AppPreferences.theme(this@MainActivity)) selectedThemeId = id
            }
            themeGroup.addView(radio)
        }
        if (selectedThemeId != View.NO_ID) themeGroup.check(selectedThemeId)
        content.addView(themeGroup)

        content.addView(sectionLabel("Reading"))
        val largeTextSwitch = Switch(this).apply {
            text = "Use larger lookup text"
            setTextColor(colorFromTheme(android.R.attr.textColorPrimary))
            isChecked = AppPreferences.largeResultText(this@MainActivity)
        }
        content.addView(largeTextSwitch)

        val synonymsSwitch = Switch(this).apply {
            text = "Show synonyms in search results"
            setTextColor(colorFromTheme(android.R.attr.textColorPrimary))
            isChecked = AppPreferences.showSynonyms(this@MainActivity)
        }
        content.addView(synonymsSwitch)

        val clearButton = Button(this).apply {
            text = "Clear all saved words"
            isAllCaps = false
            setOnClickListener { confirmClearSavedWords() }
        }
        content.addView(clearButton)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Settings")
            .setView(scroll)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Apply", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val chosenTheme = themeValues.firstOrNull { (_, label) ->
                    val checked = themeGroup.checkedRadioButtonId
                    themeGroup.findViewById<RadioButton>(checked)?.text == label
                }?.first ?: AppPreferences.THEME_LIGHT
                AppPreferences.setTheme(this, chosenTheme)
                AppPreferences.setLargeResultText(this, largeTextSwitch.isChecked)
                AppPreferences.setShowSynonyms(this, synonymsSwitch.isChecked)
                dialog.dismiss()
                recreate()
                refreshBubbleThemeIfRunning()
            }
        }
        dialog.show()
    }

    private fun confirmClearSavedWords() {
        AlertDialog.Builder(this)
            .setTitle("Clear saved words?")
            .setMessage("This removes all words saved on this device.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear") { _, _ ->
                SavedWordsStore.clear(this)
                refreshSavedWords()
            }
            .show()
    }

    private fun refreshBubbleThemeIfRunning() {
        if (!FloatingService.isRunning) return
        val intent = Intent(this, FloatingService::class.java)
            .setAction(FloatingService.ACTION_REFRESH_THEME)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun sectionLabel(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(colorFromTheme(android.R.attr.textColorPrimary))
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(16), 0, dp(4))
    }

    private fun colorFromTheme(attribute: Int): Int {
        val value = TypedValue()
        theme.resolveAttribute(attribute, value, true)
        return if (value.resourceId != 0) getColor(value.resourceId) else value.data
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
