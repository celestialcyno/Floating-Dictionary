# Floating Dictionary v1.5

A lightweight Android overlay for English word definitions while reading in other apps. The app uses the uploaded dictionary illustration, native Android views, and `HttpURLConnection`; it has no third-party runtime libraries.

## What's new in v1.5

- Refreshed, light-first home screen with **Light**, **Dark**, and **Follow device** appearance options.
- Readability setting for larger lookup text and an option to turn synonym lookups on or off.
- Saved words appear on the main page with their stored definitions and synonyms. Saved data stays on this device.
- Lookup panel displays Wiktionary definitions and requests synonyms separately, so synonyms do not depend on Wiktionary providing them in its definition response.
- The draggable bubble can still be turned off from inside the panel.

## Requirements and version

- Android 10 or newer (`minSdk 29`); project `targetSdk` is 29.
- Java 8 bytecode compatibility; build with Android Gradle Plugin 8.6.1, Kotlin plugin 2.0.21, Android SDK Platform 35, and JDK 17.
- Android app version: `1.5`; Android version code: `8`.

## Build

Open the project root in Android Studio and sync Gradle, or run this command where Android SDK Platform 35 and JDK 17 are installed:

```sh
./gradlew assembleDebug
```

The result is `app/build/outputs/apk/debug/app-debug.apk`. This is a **debug-signed testing build**. For production distribution, make a release-signed APK or Play upload bundle with a keystore that you control and securely back up. Never commit that keystore or its passwords to this repository.

## Use

1. Open **Floating Dictionary** and choose **Allow overlay & continue**.
2. Enable **Display over other apps** in Android settings. The floating bubble then starts.
3. Drag the bubble to move it, or tap it to open the lookup panel.
4. Enter an English word and press **Search**. Press **Save word** to keep the result on the main page.
5. Open **Settings** to select light, dark, or device theme; enlarge lookup text; enable or disable synonyms; or clear saved words.
6. Press **Turn off** inside the panel to remove the bubble. Open the app and start it again when you need it.

## Word data sources

Definitions come from the experimental structured English Wiktionary endpoint: `https://en.wiktionary.org/api/rest_v1/page/definition/{word}`. The app also checks Wiktionary's returned synonym fields when present.

When synonym lookup is enabled, the app additionally queries Datamuse with the `rel_syn` relationship, whose documentation describes synonyms as words in the same WordNet synset. Datamuse returns a JSON list of candidate words. Some words or senses may have no exact results; the app reports that clearly instead of pretending related terms are exact synonyms. [1] [2]

Datamuse asks publicly available apps to acknowledge its API in their documentation, so this README and the lookup panel identify the source. Its current documentation states keyless use up to 100,000 requests per day until January 1, 2027. Re-check its current access terms before a longer-term public launch; do not embed a private API key in the Android client. [1]

## Project files

- `app/src/main/java/com/example/floatingdictionary/MainActivity.kt` — themed home, overlay permission flow, saved words, and settings.
- `app/src/main/java/com/example/floatingdictionary/FloatingService.kt` — draggable overlay, definition and synonym lookup, and save control.
- `app/src/main/java/com/example/floatingdictionary/AppPreferences.kt` — theme, result-size, and synonym preferences.
- `app/src/main/java/com/example/floatingdictionary/SavedWordsStore.kt` — local saved-word storage.
- `app/src/main/res/` — layouts, theme resources, and launcher icon assets.
- `branding/` — supplied logo and its launcher-size master.
- `Floating-Dictionary-source.md` — complete text source listing; image and Gradle wrapper binary assets are included separately in the project ZIP.

## References

[1]: https://www.datamuse.com/api/ "Datamuse API documentation"
[2]: https://www.mediawiki.org/wiki/Wikimedia_REST_API "Wikimedia REST API documentation"
