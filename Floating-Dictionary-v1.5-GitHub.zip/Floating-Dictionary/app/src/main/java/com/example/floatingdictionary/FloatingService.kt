package com.example.floatingdictionary

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.Html
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeoutException
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class FloatingService : Service() {

    companion object {
        private const val CHANNEL_ID = "floating_dictionary_service"
        private const val NOTIFICATION_ID = 1001
        const val ACTION_REFRESH_THEME = "com.example.floatingdictionary.REFRESH_THEME"

        @Volatile
        var isRunning: Boolean = false
            private set
    }

    private data class HttpPayload(val status: Int, val body: String)

    private data class ParsedDefinition(
        val text: String,
        val wiktionarySynonyms: List<String>
    )

    private data class LookupResult(
        val word: String,
        val definition: String,
        val synonyms: List<String>,
        val synonymsAvailable: Boolean,
        val definitionUrl: String
    )

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var panelOpen = false
    private var lastLookup: LookupResult? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val lookupExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val networkExecutor: ExecutorService = Executors.newFixedThreadPool(2)

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        isRunning = true
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (intent?.action == ACTION_REFRESH_THEME && overlayView != null) {
            removeOverlay()
            showOverlay()
        } else if (overlayView == null) {
            showOverlay()
        }
        return START_STICKY
    }

    private fun showOverlay() {
        val themedContext = ContextThemeWrapper(this, AppPreferences.resolveTheme(this))
        val root = LayoutInflater.from(themedContext).inflate(R.layout.floating_layout, null)
        val bubble = root.findViewById<TextView>(R.id.floatingBubble)
        val panel = root.findViewById<View>(R.id.searchPanel)
        val wordInput = root.findViewById<EditText>(R.id.wordInput)
        val searchButton = root.findViewById<Button>(R.id.searchButton)
        val saveButton = root.findViewById<Button>(R.id.saveWordButton)
        val closeButton = root.findViewById<Button>(R.id.closeButton)
        val stopBubbleButton = root.findViewById<Button>(R.id.stopBubbleButton)
        val definitionText = root.findViewById<TextView>(R.id.definitionText)

        definitionText.textSize = if (AppPreferences.largeResultText(this)) 16f else 14f
        saveButton.isEnabled = false

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(120)
        }

        overlayView = root
        overlayParams = params
        try {
            windowManager.addView(root, params)
        } catch (_: Exception) {
            overlayView = null
            overlayParams = null
            stopSelf()
            return
        }

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        bubble.setOnTouchListener(object : View.OnTouchListener {
            private var downRawX = 0f
            private var downRawY = 0f
            private var startX = 0
            private var startY = 0
            private var moved = false

            override fun onTouch(view: View, event: MotionEvent): Boolean {
                val currentParams = overlayParams ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downRawX = event.rawX
                        downRawY = event.rawY
                        startX = currentParams.x
                        startY = currentParams.y
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - downRawX
                        val dy = event.rawY - downRawY
                        if (abs(dx) > touchSlop || abs(dy) > touchSlop) moved = true
                        if (moved) {
                            currentParams.x = startX + dx.toInt()
                            currentParams.y = startY + dy.toInt()
                            try {
                                windowManager.updateViewLayout(root, currentParams)
                            } catch (_: Exception) {
                                // The overlay may be removed while the user is dragging.
                            }
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) togglePanel(panel, wordInput)
                        return true
                    }
                    MotionEvent.ACTION_CANCEL -> return true
                }
                return true
            }
        })

        fun performSearch() {
            val word = wordInput.text.toString().trim()
            if (word.isEmpty()) {
                definitionText.text = "Type an English word to look it up."
            } else {
                lookupWord(word, definitionText, saveButton)
            }
        }

        searchButton.setOnClickListener { performSearch() }
        wordInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                performSearch()
                true
            } else {
                false
            }
        }
        saveButton.setOnClickListener {
            val lookup = lastLookup ?: return@setOnClickListener
            if (SavedWordsStore.contains(this, lookup.word)) {
                SavedWordsStore.remove(this, lookup.word)
                saveButton.text = "Save word"
            } else {
                SavedWordsStore.save(this, lookup.word, lookup.definition, lookup.synonyms)
                saveButton.text = "Saved ✓"
            }
        }
        closeButton.setOnClickListener { closePanel(panel, wordInput) }
        stopBubbleButton.setOnClickListener {
            closePanel(panel, wordInput)
            stopSelf()
        }
    }

    private fun togglePanel(panel: View, wordInput: EditText) {
        if (panelOpen) {
            closePanel(panel, wordInput)
            return
        }
        val root = overlayView ?: return
        val params = overlayParams ?: return
        panel.visibility = View.VISIBLE
        panelOpen = true
        params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        try {
            windowManager.updateViewLayout(root, params)
        } catch (_: Exception) {
            return
        }
        wordInput.requestFocus()
        wordInput.post {
            val inputMethodManager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            inputMethodManager.showSoftInput(wordInput, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun closePanel(panel: View, wordInput: EditText) {
        val root = overlayView ?: return
        val params = overlayParams ?: return
        val inputMethodManager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(wordInput.windowToken, 0)
        panel.visibility = View.GONE
        wordInput.clearFocus()
        panelOpen = false
        params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        try {
            windowManager.updateViewLayout(root, params)
        } catch (_: Exception) {
            // The service may be shutting down.
        }
    }

    private fun lookupWord(word: String, output: TextView, saveButton: Button) {
        output.text = "Looking up the definition and synonyms…"
        saveButton.isEnabled = false
        saveButton.text = "Save word"
        lastLookup = null
        val includeSynonyms = AppPreferences.showSynonyms(this)

        lookupExecutor.execute {
            val definitionFuture = networkExecutor.submit<HttpPayload> {
                request(
                    "https://en.wiktionary.org/api/rest_v1/page/definition/${encodePath(word)}",
                    "application/json"
                )
            }
            val synonymFuture = if (includeSynonyms) {
                networkExecutor.submit<List<String>?> { fetchDatamuseSynonyms(word) }
            } else {
                null
            }

            var definitionFailureText = "Could not reach Wiktionary. Check your connection and try again."
            val definitionPayload = try {
                definitionFuture.get(17, TimeUnit.SECONDS)
            } catch (exception: Exception) {
                definitionFuture.cancel(true)
                val cause = exception.cause ?: exception
                definitionFailureText = if (cause is TimeoutException || cause is java.net.SocketTimeoutException) {
                    "The definition request timed out. Check your connection and try again."
                } else {
                    "Could not reach Wiktionary. Check your connection and try again."
                }
                null
            }
            val parsed = if (definitionPayload?.status == HttpURLConnection.HTTP_OK) {
                try {
                    parseDefinition(definitionPayload.body)
                } catch (_: Exception) {
                    null
                }
            } else {
                null
            }
            val synonymsFromDatamuse: List<String>? = try {
                synonymFuture?.get(13, TimeUnit.SECONDS)
            } catch (_: Exception) {
                synonymFuture?.cancel(true)
                null
            }

            val failureText = when {
                definitionPayload == null -> definitionFailureText
                definitionPayload.status == HttpURLConnection.HTTP_NOT_FOUND -> "No English Wiktionary entry was found for ‘$word’."
                definitionPayload.status !in 200..299 -> "Wiktionary returned HTTP ${definitionPayload.status}. Please try again."
                parsed == null -> "Wiktionary returned no readable English definition for ‘$word’."
                else -> null
            }

            val lookup = if (parsed != null && failureText == null) {
                val mergedSynonyms = LinkedHashSet<String>()
                parsed.wiktionarySynonyms.forEach { mergedSynonyms.add(it) }
                (synonymsFromDatamuse ?: emptyList()).forEach { candidate ->
                    if (!candidate.equals(word, ignoreCase = true)) mergedSynonyms.add(candidate)
                }
                val pageTitle = encodePath(word.replace(' ', '_'))
                LookupResult(
                    word = word,
                    definition = parsed.text,
                    synonyms = mergedSynonyms.take(12),
                    synonymsAvailable = synonymsFromDatamuse != null || parsed.wiktionarySynonyms.isNotEmpty(),
                    definitionUrl = "https://en.wiktionary.org/wiki/$pageTitle"
                )
            } else {
                null
            }
            val display = if (lookup != null) {
                formatResult(lookup, includeSynonyms)
            } else {
                val synonymHint = if (includeSynonyms && !synonymsFromDatamuse.isNullOrEmpty()) {
                    "\n\nRelated synonyms from Datamuse: ${synonymsFromDatamuse.take(8).joinToString(", ")}"
                } else {
                    ""
                }
                (failureText ?: "Lookup failed. Please try again.") + synonymHint
            }

            mainHandler.post {
                if (overlayView != null && output.isAttachedToWindow) {
                    output.text = display
                    lastLookup = lookup
                    saveButton.isEnabled = lookup != null
                    saveButton.text = if (lookup != null && SavedWordsStore.contains(this, lookup.word)) {
                        "Saved ✓"
                    } else {
                        "Save word"
                    }
                }
            }
        }
    }

    private fun request(url: String, accept: String): HttpPayload {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 8_000
            connection.readTimeout = 10_000
            connection.setRequestProperty("Accept", accept)
            connection.setRequestProperty(
                "User-Agent",
                "FloatingDictionary/1.5 (Android; dictionary definitions and synonyms)"
            )
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val body = if (stream != null) {
                BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
            } else {
                ""
            }
            return HttpPayload(status, body)
        } finally {
            connection.disconnect()
        }
    }

    private fun parseDefinition(response: String): ParsedDefinition? {
        val entries = JSONObject(response).optJSONArray("en") ?: JSONArray()
        val definitions = mutableListOf<String>()
        val synonyms = LinkedHashSet<String>()

        for (entryIndex in 0 until entries.length()) {
            val entry = entries.optJSONObject(entryIndex) ?: continue
            val partOfSpeech = entry.optString("partOfSpeech", "").trim()
            val definitionArray = entry.optJSONArray("definitions") ?: JSONArray()
            for (definitionIndex in 0 until definitionArray.length()) {
                if (definitions.size >= 7) break
                val definitionObject = definitionArray.optJSONObject(definitionIndex) ?: continue
                val html = definitionObject.optString("definition", "")
                val clean = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY)
                    .toString()
                    .replace(Regex("\\s+"), " ")
                    .trim()
                if (clean.isNotBlank()) {
                    val prefix = if (partOfSpeech.isNotBlank()) "$partOfSpeech: " else ""
                    definitions.add("• $prefix$clean")
                }
                addJsonStrings(synonyms, definitionObject.optJSONArray("synonyms"))
            }
            addJsonStrings(synonyms, entry.optJSONArray("synonyms"))
            if (definitions.size >= 7) break
        }
        if (definitions.isEmpty()) return null
        return ParsedDefinition(definitions.joinToString("\n"), synonyms.toList())
    }

    private fun fetchDatamuseSynonyms(word: String): List<String>? {
        val encoded = URLEncoder.encode(word, "UTF-8")
        val response = request(
            "https://api.datamuse.com/words?rel_syn=$encoded&max=12",
            "application/json"
        )
        if (response.status !in 200..299) return null
        val array = JSONArray(response.body)
        val synonyms = LinkedHashSet<String>()
        for (index in 0 until array.length()) {
            val item = array.optJSONObject(index) ?: continue
            val value = item.optString("word", "").trim()
            if (value.isNotEmpty() && !value.equals(word, ignoreCase = true)) synonyms.add(value)
        }
        return synonyms.toList()
    }

    private fun formatResult(lookup: LookupResult, includeSynonyms: Boolean): String = buildString {
        append(lookup.word)
        append("\n\nDEFINITION\n")
        append(lookup.definition)
        if (includeSynonyms) {
            append("\n\nSYNONYMS (Datamuse / WordNet)\n")
            if (lookup.synonyms.isEmpty()) {
                append(
                    if (lookup.synonymsAvailable) {
                        "No exact synonyms were returned for this word."
                    } else {
                        "The synonym service is temporarily unavailable. Try again later."
                    }
                )
            } else {
                append(lookup.synonyms.joinToString(", "))
            }
        }
        append("\n\nDefinition source: English Wiktionary\n")
        append(lookup.definitionUrl)
        if (includeSynonyms) {
            append("\n\nSynonym source: Datamuse API\nhttps://www.datamuse.com/api/")
        }
    }.trim()

    private fun addJsonStrings(destination: MutableSet<String>, values: JSONArray?) {
        if (values == null) return
        for (index in 0 until values.length()) {
            val value = values.optString(index).trim()
            if (value.isNotEmpty()) destination.add(value)
        }
    }

    private fun encodePath(value: String): String =
        URLEncoder.encode(value, "UTF-8").replace("+", "%20")

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Floating Dictionary",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the floating dictionary bubble available"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val activityIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            activityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Floating Dictionary is running")
            .setContentText("Tap the floating bubble to search for a word")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun removeOverlay() {
        val oldView = overlayView
        if (oldView != null) {
            try {
                windowManager.removeViewImmediate(oldView)
            } catch (_: Exception) {
                // The view may already have been detached.
            }
        }
        overlayView = null
        overlayParams = null
        panelOpen = false
        lastLookup = null
    }

    override fun onDestroy() {
        removeOverlay()
        lookupExecutor.shutdownNow()
        networkExecutor.shutdownNow()
        stopForeground(true)
        isRunning = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
