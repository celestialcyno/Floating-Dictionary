# Floating Dictionary (Android/Kotlin)

A lightweight Android overlay bubble for looking up English word definitions from English Wiktionary. The app uses platform Android views and `HttpURLConnection`; there are no third-party runtime dependencies. The launcher and app screen use the latest uploaded square dictionary illustration as the app logo.

## Release version

- **App version shown to users:** `1.0`
- **Internal release designation:** `1.5`
- **Android version code:** `7` (monotonically increasing update number)

## Requirements

- Android 10 or newer (`minSdk 29`); target API 29.
- Java 8 bytecode compatibility. Build with Android Gradle Plugin 8.6.1, Kotlin plugin 2.0.21, Android SDK Platform 35, and JDK 17.
- `minSdk = 29` means Android 9 and earlier are not supported. The service retains a legacy `TYPE_PHONE` branch, but with this minimum SDK the branch is unreachable.

## Build

Open the project root in Android Studio, sync Gradle, and build the `app` configuration. From a terminal with Android SDK Platform 35 and JDK 17 installed, run:

```sh
./gradlew assembleDebug
```

The output is `app/build/outputs/apk/debug/app-debug.apk`. This is a debug-signed testing build; create a release-signed build for production distribution.

## Use

1. Launch **Floating Dictionary** and press **Grant permission and start**.
2. Enable **Display over other apps** in Android settings; the bubble starts when you return.
3. Drag the floating bubble to move it. Tap it to open the search panel, enter a word, and press **Search**.
4. Press **×** to hide only the panel and keep the bubble running. Press **Turn off** inside the panel to stop the foreground service and remove the bubble. Later, open the app and press **Start floating bubble** to show it again.

The foreground service shows a persistent low-importance notification while active. **Turn off** removes the notification too.

## Dictionary source

Lookups use only English Wiktionary's structured endpoint: `https://en.wiktionary.org/api/rest_v1/page/definition/{word}`. Definitions are parsed from the returned English entries, with a clickable Wiktionary source link and attribution. Wiktionary's structured response does not consistently include synonyms; when it does not, the app links to the Wiktionary article for related terms. Network errors are displayed in the search panel and can be retried.

## Project files

- `app/src/main/AndroidManifest.xml` — permissions, launcher activity, app label, and service declaration.
- `app/src/main/java/com/example/floatingdictionary/MainActivity.kt` — overlay permission handling and service start action.
- `app/src/main/java/com/example/floatingdictionary/FloatingService.kt` — foreground service, overlay, drag behavior, stop control, HTTP lookup, and parsing.
- `app/src/main/res/mipmap-*` — density-scaled launcher icon assets from the latest uploaded image.
- `branding/` — exact uploaded image and a scaled launcher-icon master.
- `Floating-Dictionary-source.md` — complete code blocks for the source and build files.

## API references

- [Wikimedia REST API documentation](https://www.mediawiki.org/wiki/Wikimedia_REST_API)
- [English Wiktionary definition endpoint](https://en.wiktionary.org/api/rest_v1/#!/Page_content/get_page_definition_term)
