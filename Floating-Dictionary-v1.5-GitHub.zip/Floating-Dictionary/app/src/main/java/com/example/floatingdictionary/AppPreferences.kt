package com.example.floatingdictionary

import android.content.Context
import android.content.res.Configuration

object AppPreferences {
    const val THEME_LIGHT = "light"
    const val THEME_DARK = "dark"
    const val THEME_SYSTEM = "system"

    private const val PREFS_NAME = "floating_dictionary_preferences"
    private const val KEY_THEME = "theme"
    private const val KEY_LARGE_TEXT = "large_result_text"
    private const val KEY_SHOW_SYNONYMS = "show_synonyms"

    private fun preferences(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun theme(context: Context): String =
        preferences(context).getString(KEY_THEME, THEME_LIGHT) ?: THEME_LIGHT

    fun setTheme(context: Context, value: String) {
        preferences(context).edit().putString(KEY_THEME, value).apply()
    }

    fun largeResultText(context: Context): Boolean =
        preferences(context).getBoolean(KEY_LARGE_TEXT, false)

    fun setLargeResultText(context: Context, enabled: Boolean) {
        preferences(context).edit().putBoolean(KEY_LARGE_TEXT, enabled).apply()
    }

    fun showSynonyms(context: Context): Boolean =
        preferences(context).getBoolean(KEY_SHOW_SYNONYMS, true)

    fun setShowSynonyms(context: Context, enabled: Boolean) {
        preferences(context).edit().putBoolean(KEY_SHOW_SYNONYMS, enabled).apply()
    }

    fun resolveTheme(context: Context): Int {
        val useDark = when (theme(context)) {
            THEME_DARK -> true
            THEME_SYSTEM -> {
                val nightMode = context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
                nightMode == Configuration.UI_MODE_NIGHT_YES
            }
            else -> false
        }
        return if (useDark) R.style.AppThemeDark else R.style.AppTheme
    }
}
